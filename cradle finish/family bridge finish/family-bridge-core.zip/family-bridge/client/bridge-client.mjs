/**
 * Family Bridge — Client
 * A tiny, framework-agnostic client for talking to the bridge daemon.
 * No dependencies beyond global fetch (Node 18+). Works in any runtime.
 *
 * Usage:
 *   import { FamilyBridge } from './bridge-client.mjs';
 *   const bridge = new FamilyBridge({ url: 'http://localhost:9099', agent: 'lazarus' });
 *   await bridge.send('atlas', 'ready for review');
 *   const unread = await bridge.unread();
 *   await bridge.markRead(unread.map(m => m.id));
 */

export class FamilyBridge {
  /** @param {{url?:string, agent:string, fetchImpl?:typeof fetch}} opts */
  constructor({ url = 'http://localhost:9099', agent, fetchImpl } = {}) {
    if (!agent) throw new Error('FamilyBridge: "agent" id is required');
    this.url = url.replace(/\/$/, '');
    this.agent = agent;
    this.fetch = fetchImpl || globalThis.fetch;
    if (!this.fetch) throw new Error('FamilyBridge: no fetch available (Node 18+ or pass fetchImpl)');
  }

  async _post(path, body) {
    const r = await this.fetch(`${this.url}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return r.json();
  }
  async _get(path) {
    const r = await this.fetch(`${this.url}${path}`);
    return r.json();
  }

  /** Send a message. `to` omitted/null = broadcast to everyone. */
  async send(to, content) {
    if (content === undefined) { content = to; to = null; }   // send(content) broadcasts
    const res = await this._post('/send', { from: this.agent, to, content });
    if (!res.ok) throw new Error(`send rejected: ${res.reason}`);
    return res.message;
  }

  /** Messages addressed to me (or broadcast) that I haven't read yet. */
  async unread() {
    const res = await this._get(`/unread?agent=${encodeURIComponent(this.agent)}`);
    return res.unread || [];
  }

  /** Mark messages read. Pass an array of ids, or omit to mark all mine read. */
  async markRead(ids = null) {
    const res = await this._post('/read', { agent: this.agent, ids });
    return res.marked || 0;
  }

  /** Recent messages across the whole bridge (for context / debugging). */
  async history(limit = 50) {
    const res = await this._get(`/messages?limit=${limit}`);
    return res.messages || [];
  }

  async health() { return this._get('/health'); }

  /**
   * Subscribe to live messages via Server-Sent Events.
   * Returns a stop() function. Node 18+ (uses fetch streaming).
   */
  async subscribe(onMessage) {
    const r = await this.fetch(`${this.url}/stream`);
    const reader = r.body.getReader();
    const dec = new TextDecoder();
    let buf = '', stopped = false;
    (async () => {
      while (!stopped) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split('\n\n');
        buf = parts.pop();
        for (const p of parts) {
          const line = p.split('\n').find(l => l.startsWith('data: '));
          if (!line) continue;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === 'message') onMessage(evt.message);
          } catch { /* skip keep-alive pings */ }
        }
      }
    })().catch(() => {});
    return () => { stopped = true; try { reader.cancel(); } catch {} };
  }
}

export default FamilyBridge;
