/**
 * Family Bridge — Core smoke test
 * Tests the pure logic (no network needed). Run: node test/smoke.test.mjs
 * Exits 0 only if every assertion passes.
 */

import {
  handleMessage, unreadFor, markRead, detectLoop, CFG, _reset,
} from '../daemon/bridge-daemon.mjs';

let passed = 0, failed = 0;
function ok(name, cond) {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else      { failed++; console.log(`  ✗ ${name}`); }
}

console.log('Family Bridge — core smoke test\n');
_reset();

// 1) Valid directed message is accepted and stored.
const m1 = handleMessage('atlas', 'design ready', 'lazarus');
ok('accepts a valid directed message', m1 && !m1.blocked && m1.id);
ok('stamps sender, recipient, content', m1.from === 'atlas' && m1.to === 'lazarus' && m1.content === 'design ready');

// 2) Broadcast (no recipient) is accepted with to=null.
const m2 = handleMessage('molly', 'standup in 5');
ok('accepts a broadcast (to=null)', m2 && !m2.blocked && m2.to === null);

// 3) Validation rejects bad input.
ok('rejects empty content', handleMessage('atlas', '').blocked === true);
ok('rejects missing sender', handleMessage('', 'hi', 'atlas').blocked === true);
ok('rejects self-message', handleMessage('atlas', 'hi', 'atlas').reason === 'self_message');

// 4) Read tracking: lazarus has unread (the directed msg + the broadcast),
//    but not atlas's own message, and not after marking read.
const unreadBefore = unreadFor('lazarus');
ok('lazarus sees unread (directed + broadcast)', unreadBefore.length === 2);
ok('sender does not see own message as unread', !unreadFor('atlas').some(m => m.id === m1.id));

const marked = markRead('lazarus');
ok('markRead marks the right count', marked === 2);
ok('nothing unread after markRead', unreadFor('lazarus').length === 0);

// 5) THE BIG ONE — loop garden actually blocks a storm.
//    Semantic: LOOP_THRESHOLD identical messages are tolerated; the next
//    identical one is blocked. Default threshold = 3  ->  4th is blocked.
_reset();
const r1 = handleMessage('echo', 'ping', 'pong');   // 1st: tolerated
const r2 = handleMessage('echo', 'ping', 'pong');   // 2nd: tolerated
const r3 = handleMessage('echo', 'ping', 'pong');   // 3rd: tolerated (now 3 on the board)
const r4 = handleMessage('echo', 'ping', 'pong');   // 4th: BLOCKED
ok('1st identical message passes', !r1.blocked);
ok('2nd identical message passes', !r2.blocked);
ok('3rd identical message passes (at tolerance)', !r3.blocked);
ok('4th identical message is BLOCKED by loop garden', r4.blocked === true && r4.reason === 'loop_detected');
ok('detectLoop reports the loop once at threshold', detectLoop('echo', 'ping') === true);
ok('a DIFFERENT message from same sender still passes', !handleMessage('echo', 'something new', 'pong').blocked);

// 6) Config sanity.
ok('loop threshold is a positive integer', Number.isInteger(CFG.LOOP_THRESHOLD) && CFG.LOOP_THRESHOLD > 0);

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
