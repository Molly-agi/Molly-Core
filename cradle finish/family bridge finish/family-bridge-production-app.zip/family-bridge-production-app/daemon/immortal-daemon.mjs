#!/usr/bin/env node
/**
 * =============================================================================
 * IMMORTAL DAEMON - The One Bridge
 * =============================================================================
 *
 * One process that does everything:
 * 1. Aggressive heartbeat (every 2 seconds)
 * 2. Ghost hunting (kills zombie processes)
 * 3. Bridge guardian (restarts bridge if dead)
 * 4. Multiple activity types (file, git, HTTP)
 * 5. SIGHUP immune (survives tab switches)
 * 6. Self-monitoring
 *
 * This replaces: keep-alive.sh, keep-alive-daemon.mjs, watchdog.sh, immortal.sh
 * =============================================================================
 */

import {
  writeFileSync,
  readFileSync,
  appendFileSync,
  existsSync,
  unlinkSync,
} from 'fs';
import { spawn, exec, execSync } from 'child_process';
import http from 'http';
import { createServer } from 'net';

// =============================================================================
// CONFIG
// =============================================================================
const ROOT = '/workspaces/Molly-Core';
const HEARTBEAT_FILE = `${ROOT}/.codespace-heartbeat`;
const PID_FILE = `${ROOT}/.immortal.pid`;
const LOG_FILE = `${ROOT}/.immortal.log`;
const BRIDGE_PID_FILE = `${ROOT}/.bridge-daemon.pid`;
const BRIDGE_LOG = `${ROOT}/.bridge-daemon.log`;
const ATLAS_BRIDGE_PID_FILE = `${ROOT}/.atlas-bridge.pid`;
const ATLAS_BRIDGE_LOG = `${ROOT}/.atlas-bridge.log`;
const GEMINI_BRIDGE_PID_FILE = `${ROOT}/.gemini-bridge.pid`;
const GEMINI_BRIDGE_LOG = `${ROOT}/.gemini-bridge.log`;
const SWITCHBOARD_PID_FILE = `${ROOT}/.switchboard.pid`;
const SWITCHBOARD_LOG = `${ROOT}/.switchboard.log`;
const LAZARUS_BRIDGE_PID_FILE = `${ROOT}/.lazarus-bridge.pid`;
const LAZARUS_BRIDGE_LOG = `${ROOT}/.lazarus-bridge.log`;
const MOLLY_LISTENER_PID_FILE = `${ROOT}/.molly-listener.pid`;
const MOLLY_LISTENER_LOG = `${ROOT}/.molly-listener.log`;
const MOLLY_TICKER_PID_FILE = `${ROOT}/.molly-ticker.pid`;
const MOLLY_TICKER_LOG = `${ROOT}/.molly-ticker.log`;

// Intervals
const HEARTBEAT_MS = 2000; // 2 seconds - half cadence
const GIT_ACTIVITY_MS = 10000; // 10 seconds
const HTTP_PING_MS = 5000; // 5 seconds
const GHOST_HUNT_MS = 30000; // 30 seconds
const BRIDGE_CHECK_MS = 15000; // 15 seconds
const STATUS_LOG_MS = 60000; // 1 minute

// =============================================================================
// LOGGING
// =============================================================================
function log(msg) {
  const ts = new Date().toISOString().substr(11, 8);
  const line = `${ts} ${msg}`;
  console.log(line);
  try {
    appendFileSync(LOG_FILE, line + '\n');
    // Rotate if too big
    const content = readFileSync(LOG_FILE, 'utf8');
    const lines = content.split('\n');
    if (lines.length > 200) {
      writeFileSync(LOG_FILE, lines.slice(-100).join('\n'));
    }
  } catch {}
}

// =============================================================================
// SINGLE INSTANCE LOCK
// =============================================================================
function acquireLock() {
  if (existsSync(PID_FILE)) {
    try {
      const oldPid = parseInt(readFileSync(PID_FILE, 'utf8').trim());
      // Check if process is still running
      try {
        process.kill(oldPid, 0);
        // Process exists - check if it's actually immortal daemon
        const cmdline = readFileSync(`/proc/${oldPid}/cmdline`, 'utf8');
        if (cmdline.includes('immortal-daemon')) {
          log(`[LOCK] Already running (PID ${oldPid}) - exiting`);
          process.exit(0);
        }
      } catch {
        // Process doesn't exist - stale lock
      }
    } catch {}
    unlinkSync(PID_FILE);
  }
  writeFileSync(PID_FILE, process.pid.toString());
  log(`[LOCK] Acquired (PID ${process.pid})`);
}

// =============================================================================
// HEARTBEAT - Every 2 seconds
// =============================================================================
let heartbeatCount = 0;

let heartbeatRunning = false;
function heartbeat() {
  if (heartbeatRunning) return;
  heartbeatRunning = true;
  heartbeatCount++;
  try {
    writeFileSync(HEARTBEAT_FILE, new Date().toISOString());
    writeFileSync(`${ROOT}/.activity-burst`, Date.now().toString());
  } catch (e) {
    log(`[ERROR] Heartbeat write failed: ${e.message}`);
  }
  heartbeatRunning = false;
}

// =============================================================================
// GIT ACTIVITY - Every 10 seconds
// =============================================================================
function gitActivity() {
  if (gitActivity.running) return;
  gitActivity.running = true;
  try {
    spawn('git', ['status', '--short'], { cwd: ROOT, stdio: 'ignore' });
    spawn('git', ['rev-parse', 'HEAD'], { cwd: ROOT, stdio: 'ignore' });
  } catch {}
  gitActivity.running = false;
}

// =============================================================================
// HTTP PING - Every 5 seconds - KEEP 9002 ALIVE (this is critical)
// =============================================================================
function httpPing() {
  if (httpPing.running) return;
  httpPing.running = true;
  // Ping dev server on 9002 - THIS IS THE MAIN ONE
  try {
    const req = http.request({
      hostname: '127.0.0.1',
      port: 9002,
      path: '/api/bridge/ping',
      method: 'GET',
      timeout: 3000,
    });
    req.on('error', () => {});
    req.end();
  } catch {}

  // Also ping the heartbeat endpoint
  try {
    const req = http.request({
      hostname: '127.0.0.1',
      port: 9002,
      path: '/api/heartbeat',
      method: 'GET',
      timeout: 3000,
    });
    req.on('error', () => {});
    req.end();
  } catch {}

  // Ping bridge directly on 9099
  try {
    const req = http.request({
      hostname: '127.0.0.1',
      port: 9099,
      path: '/ping',
      method: 'GET',
      timeout: 3000,
    });
    req.on('error', () => {});
    req.end();
  } catch {}
  httpPing.running = false;
}

// =============================================================================
// GHOST HUNTER - Every 30 seconds
// =============================================================================
function huntGhosts() {
  if (huntGhosts.running) return;
  huntGhosts.running = true;
  try {
    // Find all extension host PIDs sorted by age (newest first)
    const result = execSync(
      `ps -eo pid,etimes,args 2>/dev/null | grep "type=extensionHost" | grep -v grep | sort -k2 -n`,
      { encoding: 'utf8', timeout: 5000 }
    ).trim();

    if (!result) {
      huntGhosts.running = false;
      return;
    }

    const lines = result.split('\n').filter((l) => l.trim());
    if (lines.length <= 1) {
      huntGhosts.running = false;
      return;
    } // Only one or zero - nothing to kill

    // Keep the newest (first line after sort), kill the rest
    const newest = lines[0].trim().split(/\s+/)[0];

    for (let i = 1; i < lines.length; i++) {
      const pid = lines[i].trim().split(/\s+/)[0];
      try {
        // Kill children first
        execSync(`pkill -TERM -P ${pid} 2>/dev/null || true`, {
          timeout: 2000,
        });
        execSync(`kill -TERM ${pid} 2>/dev/null || true`, { timeout: 2000 });
        log(`[GHOST] Killed extension host ${pid} (kept ${newest})`);
      } catch {}
    }
  } catch {}
  huntGhosts.running = false;
}

// =============================================================================
// BRIDGE GUARDIAN - Every 15 seconds
// =============================================================================
function isPortListening(port) {
  try {
    const result = execSync(`ss -tlnp 2>/dev/null | grep ":${port}"`, {
      encoding: 'utf8',
      timeout: 2000,
    });
    return result.includes(`:${port}`);
  } catch {
    return false;
  }
}

function ensureBridge() {
  if (ensureBridge.running) return;
  ensureBridge.running = true;
  if (isPortListening(9099)) {
    ensureBridge.running = false;
    return;
  } // Bridge is up

  log('[BRIDGE] Port 9099 not listening - restarting bridge');

  // Clean up old PID file
  if (existsSync(BRIDGE_PID_FILE)) {
    try {
      unlinkSync(BRIDGE_PID_FILE);
    } catch {}
  }

  // Start bridge
  try {
    const child = spawn('node', [`${ROOT}/scripts/bridge-daemon.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
    });

    // Write log
    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(BRIDGE_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(BRIDGE_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(BRIDGE_PID_FILE, child.pid.toString());
    log(`[BRIDGE] Started (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start bridge: ${e.message}`);
  }
  ensureBridge.running = false;
}

// =============================================================================
// ATLAS BRIDGE GUARDIAN - Active WebSocket for CLI Agent
// =============================================================================
function ensureAtlasBridge() {
  if (ensureAtlasBridge.running) return;
  ensureAtlasBridge.running = true;

  try {
    const pidStr = existsSync(ATLAS_BRIDGE_PID_FILE)
      ? readFileSync(ATLAS_BRIDGE_PID_FILE, 'utf8').trim()
      : '';
    const pid = parseInt(pidStr);

    if (pid && !isNaN(pid)) {
      try {
        process.kill(pid, 0);
        ensureAtlasBridge.running = false;
        return; // Process still running
      } catch {
        // Process doesn't exist
      }
    }
  } catch {}

  log('[ATLAS] Bridge client not running - starting');

  try {
    if (existsSync(ATLAS_BRIDGE_PID_FILE)) {
      unlinkSync(ATLAS_BRIDGE_PID_FILE);
    }

    const child = spawn('node', [`${ROOT}/scripts/atlas-bridge.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
    });

    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(ATLAS_BRIDGE_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(ATLAS_BRIDGE_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(ATLAS_BRIDGE_PID_FILE, child.pid.toString());
    log(`[ATLAS] Bridge connected (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start Atlas bridge: ${e.message}`);
  }
  ensureAtlasBridge.running = false;
}

// =============================================================================
// GEMINI BRIDGE GUARDIAN - Active WebSocket for Gemini CLI Agent
// =============================================================================
function ensureGeminiBridge() {
  if (ensureGeminiBridge.running) return;
  ensureGeminiBridge.running = true;

  try {
    const pidStr = existsSync(GEMINI_BRIDGE_PID_FILE)
      ? readFileSync(GEMINI_BRIDGE_PID_FILE, 'utf8').trim()
      : '';
    const pid = parseInt(pidStr);

    if (pid && !isNaN(pid)) {
      try {
        process.kill(pid, 0);
        ensureGeminiBridge.running = false;
        return; // Process still running
      } catch {
        // Process doesn't exist
      }
    }
  } catch {}

  log('[GEMINI] Bridge client not running - starting');

  try {
    if (existsSync(GEMINI_BRIDGE_PID_FILE)) {
      unlinkSync(GEMINI_BRIDGE_PID_FILE);
    }

    const child = spawn('node', [`${ROOT}/scripts/gemini-bridge.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
    });

    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(GEMINI_BRIDGE_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(GEMINI_BRIDGE_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(GEMINI_BRIDGE_PID_FILE, child.pid.toString());
    log(`[GEMINI] Bridge connected (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start Gemini bridge: ${e.message}`);
  }
  ensureGeminiBridge.running = false;
}

// =============================================================================
// SWITCHBOARD GUARDIAN — Routes all bridge messages to right destinations
// =============================================================================
function ensureSwitchboard() {
  if (ensureSwitchboard.running) return;
  ensureSwitchboard.running = true;

  try {
    const pidStr = existsSync(SWITCHBOARD_PID_FILE)
      ? readFileSync(SWITCHBOARD_PID_FILE, 'utf8').trim()
      : '';
    const pid = parseInt(pidStr);

    if (pid && !isNaN(pid)) {
      try {
        process.kill(pid, 0);
        ensureSwitchboard.running = false;
        return; // Process still running
      } catch {
        // Process doesn't exist
      }
    }
  } catch {}

  log('[SWITCHBOARD] Not running - starting');

  try {
    if (existsSync(SWITCHBOARD_PID_FILE)) {
      unlinkSync(SWITCHBOARD_PID_FILE);
    }

    // Pass NTFY_TOPIC from environment if set
    const env = { ...process.env };

    const child = spawn('node', [`${ROOT}/scripts/switchboard.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
      env,
    });

    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(SWITCHBOARD_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(SWITCHBOARD_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(SWITCHBOARD_PID_FILE, child.pid.toString());
    log(`[SWITCHBOARD] Started (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start switchboard: ${e.message}`);
  }
  ensureSwitchboard.running = false;
}

// =============================================================================
// LAZARUS BRIDGE GUARDIAN
// =============================================================================
function ensureLazarusBridge() {
  if (ensureLazarusBridge.running) return;
  ensureLazarusBridge.running = true;

  try {
    const pidStr = existsSync(LAZARUS_BRIDGE_PID_FILE)
      ? readFileSync(LAZARUS_BRIDGE_PID_FILE, 'utf8').trim()
      : '';
    const pid = parseInt(pidStr);

    if (pid && !isNaN(pid)) {
      try {
        process.kill(pid, 0);
        ensureLazarusBridge.running = false;
        return; // Process still running
      } catch {
        // Process doesn't exist
      }
    }
  } catch {}

  log('[LAZARUS] Bridge client not running - starting');

  try {
    if (existsSync(LAZARUS_BRIDGE_PID_FILE)) {
      unlinkSync(LAZARUS_BRIDGE_PID_FILE);
    }

    const child = spawn('node', [`${ROOT}/scripts/lazarus-bridge.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
    });

    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(LAZARUS_BRIDGE_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(LAZARUS_BRIDGE_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(LAZARUS_BRIDGE_PID_FILE, child.pid.toString());
    log(`[LAZARUS] Bridge connected (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start Lazarus bridge: ${e.message}`);
  }
  ensureLazarusBridge.running = false;
}

// =============================================================================
// MOLLY LISTENER GUARDIAN
// =============================================================================
function ensureMollyListener() {
  if (ensureMollyListener.running) return;
  ensureMollyListener.running = true;

  try {
    const pidStr = existsSync(MOLLY_LISTENER_PID_FILE)
      ? readFileSync(MOLLY_LISTENER_PID_FILE, 'utf8').trim()
      : '';
    const pid = parseInt(pidStr);

    if (pid && !isNaN(pid)) {
      try {
        process.kill(pid, 0);
        ensureMollyListener.running = false;
        return; // Process still running
      } catch {
        // Process doesn't exist
      }
    }
  } catch {}

  log('[MOLLY-LISTENER] Not running - starting');

  try {
    if (existsSync(MOLLY_LISTENER_PID_FILE)) {
      unlinkSync(MOLLY_LISTENER_PID_FILE);
    }

    const child = spawn('node', [`${ROOT}/scripts/molly-listener.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
    });

    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(MOLLY_LISTENER_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(MOLLY_LISTENER_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(MOLLY_LISTENER_PID_FILE, child.pid.toString());
    log(`[MOLLY-LISTENER] Started (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start Molly listener: ${e.message}`);
  }
  ensureMollyListener.running = false;
}

// =============================================================================
// MOLLY TICKER GUARDIAN
// =============================================================================
function ensureMollyTicker() {
  if (ensureMollyTicker.running) return;
  ensureMollyTicker.running = true;

  try {
    const pidStr = existsSync(MOLLY_TICKER_PID_FILE)
      ? readFileSync(MOLLY_TICKER_PID_FILE, 'utf8').trim()
      : '';
    const pid = parseInt(pidStr);

    if (pid && !isNaN(pid)) {
      try {
        process.kill(pid, 0);
        ensureMollyTicker.running = false;
        return; // Process still running
      } catch {
        // Process doesn't exist
      }
    }
  } catch {}

  log('[MOLLY-TICKER] Not running - starting');

  try {
    if (existsSync(MOLLY_TICKER_PID_FILE)) {
      unlinkSync(MOLLY_TICKER_PID_FILE);
    }

    const child = spawn('node', [`${ROOT}/scripts/molly-ticker.mjs`], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,
    });

    if (child.stdout) {
      child.stdout.on('data', (data) => {
        try {
          appendFileSync(MOLLY_TICKER_LOG, data);
        } catch {}
      });
    }
    if (child.stderr) {
      child.stderr.on('data', (data) => {
        try {
          appendFileSync(MOLLY_TICKER_LOG, data);
        } catch {}
      });
    }

    child.unref();
    writeFileSync(MOLLY_TICKER_PID_FILE, child.pid.toString());
    log(`[MOLLY-TICKER] Started (PID ${child.pid})`);
  } catch (e) {
    log(`[ERROR] Failed to start Molly ticker: ${e.message}`);
  }
  ensureMollyTicker.running = false;
}

// =============================================================================
// STATUS LOG - Every 1 minute
// =============================================================================
function logStatus() {
  if (logStatus.running) return;
  logStatus.running = true;
  try {
    const mem = execSync(`free -m 2>/dev/null | awk '/^Mem:/{print $7}'`, {
      encoding: 'utf8',
      timeout: 2000,
    }).trim();
    const extHosts = execSync(
      `ps aux 2>/dev/null | grep "type=extensionHost" | grep -v grep | wc -l`,
      { encoding: 'utf8', timeout: 2000 }
    ).trim();
    const bridge = isPortListening(9099) ? 'UP' : 'DOWN';
    const devServer = isPortListening(9002) ? 'UP' : 'DOWN';
    const uptime = Math.floor(process.uptime());

    // Check bridge clients
    let atlasStatus = 'OFF';
    let geminiStatus = 'OFF';
    let lazarusStatus = 'OFF';
    let listenerStatus = 'OFF';
    let tickerStatus = 'OFF';

    try {
      const pidStr = existsSync(ATLAS_BRIDGE_PID_FILE)
        ? readFileSync(ATLAS_BRIDGE_PID_FILE, 'utf8').trim()
        : '';
      const pid = parseInt(pidStr);
      if (pid && !isNaN(pid)) {
        try {
          process.kill(pid, 0);
          atlasStatus = 'ON';
        } catch {}
      }
    } catch {}

    try {
      const pidStr = existsSync(GEMINI_BRIDGE_PID_FILE)
        ? readFileSync(GEMINI_BRIDGE_PID_FILE, 'utf8').trim()
        : '';
      const pid = parseInt(pidStr);
      if (pid && !isNaN(pid)) {
        try {
          process.kill(pid, 0);
          geminiStatus = 'ON';
        } catch {}
      }
    } catch {}

    try {
      const pidStr = existsSync(LAZARUS_BRIDGE_PID_FILE)
        ? readFileSync(LAZARUS_BRIDGE_PID_FILE, 'utf8').trim()
        : '';
      const pid = parseInt(pidStr);
      if (pid && !isNaN(pid)) {
        try {
          process.kill(pid, 0);
          lazarusStatus = 'ON';
        } catch {}
      }
    } catch {}

    try {
      const pidStr = existsSync(MOLLY_LISTENER_PID_FILE)
        ? readFileSync(MOLLY_LISTENER_PID_FILE, 'utf8').trim()
        : '';
      const pid = parseInt(pidStr);
      if (pid && !isNaN(pid)) {
        try {
          process.kill(pid, 0);
          listenerStatus = 'ON';
        } catch {}
      }
    } catch {}

    try {
      const pidStr = existsSync(MOLLY_TICKER_PID_FILE)
        ? readFileSync(MOLLY_TICKER_PID_FILE, 'utf8').trim()
        : '';
      const pid = parseInt(pidStr);
      if (pid && !isNaN(pid)) {
        try {
          process.kill(pid, 0);
          tickerStatus = 'ON';
        } catch {}
      }
    } catch {}

    log(
      `[STATUS] uptime=${uptime}s beats=${heartbeatCount} mem=${mem}MB extHosts=${extHosts} bridge=${bridge} dev=${devServer} atlas=${atlasStatus} gemini=${geminiStatus} lazarus=${lazarusStatus} listener=${listenerStatus} ticker=${tickerStatus}`
    );
  } catch {}
  logStatus.running = false;
}
// SIGNAL HANDLERS - IMMUNE TO EVERYTHING EXCEPT SIGKILL
// =============================================================================
process.on('SIGHUP', () => log('[SIGNAL] SIGHUP ignored'));
process.on('SIGTERM', () => log('[SIGNAL] SIGTERM ignored'));
process.on('SIGINT', () => log('[SIGNAL] SIGINT ignored'));
process.on('SIGQUIT', () => log('[SIGNAL] SIGQUIT ignored'));
process.on('SIGTSTP', () => log('[SIGNAL] SIGTSTP ignored'));

process.on('uncaughtException', (err) => {
  log(`[ERROR] Uncaught exception: ${err.message}`);
  // Don't exit - keep running
});

process.on('unhandledRejection', (err) => {
  log(`[ERROR] Unhandled rejection: ${err}`);
  // Don't exit - keep running
});

// =============================================================================
// MAIN
// =============================================================================
console.log('='.repeat(60));
console.log('IMMORTAL DAEMON - The One Bridge');
console.log('='.repeat(60));

acquireLock();

log('[START] Immortal Daemon starting');
log(
  `[CONFIG] Heartbeat: ${HEARTBEAT_MS}ms | Git: ${GIT_ACTIVITY_MS}ms | HTTP: ${HTTP_PING_MS}ms`
);
log(
  `[CONFIG] Ghost: ${GHOST_HUNT_MS}ms | Bridge: ${BRIDGE_CHECK_MS}ms | Status: ${STATUS_LOG_MS}ms`
);

// Initial run of everything
heartbeat();
gitActivity();
httpPing();
ensureBridge();
ensureSwitchboard();
ensureAtlasBridge();
ensureGeminiBridge();
ensureLazarusBridge();
ensureMollyListener();
ensureMollyTicker();
huntGhosts();

// Start all intervals
setInterval(heartbeat, HEARTBEAT_MS);
setInterval(gitActivity, GIT_ACTIVITY_MS);
setInterval(httpPing, HTTP_PING_MS);
setInterval(huntGhosts, GHOST_HUNT_MS);
setInterval(ensureBridge, BRIDGE_CHECK_MS);
setInterval(ensureSwitchboard, BRIDGE_CHECK_MS);
setInterval(ensureAtlasBridge, BRIDGE_CHECK_MS);
setInterval(ensureGeminiBridge, BRIDGE_CHECK_MS);
setInterval(ensureLazarusBridge, BRIDGE_CHECK_MS);
setInterval(ensureMollyListener, BRIDGE_CHECK_MS);
setInterval(ensureMollyTicker, BRIDGE_CHECK_MS);
setInterval(logStatus, STATUS_LOG_MS);

// ===================== HEARTBEAT DASHBOARD AUTOSTART =====================
function ensureHeartbeatDashboard() {
  if (ensureHeartbeatDashboard.running) return;
  ensureHeartbeatDashboard.running = true;
  const DASHBOARD_PID_FILE = `${ROOT}/.heartbeat-dashboard.pid`;
  const DASHBOARD_PATH = `${ROOT}/public/heartbeat-dashboard.html`;
  const DASHBOARD_API_PATH = `${ROOT}/scripts/heartbeat-api.js`;
  // Check if heartbeat-api is running (port 9100)
  if (!isPortListening(9100)) {
    log('[DASHBOARD] Heartbeat API not running - starting');
    try {
      const child = spawn('node', [DASHBOARD_API_PATH], {
        cwd: ROOT,
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: true,
      });
      child.unref();
      writeFileSync(DASHBOARD_PID_FILE, child.pid.toString());
      log(`[DASHBOARD] Heartbeat API started (PID ${child.pid})`);
    } catch (e) {
      log(`[ERROR] Failed to start Heartbeat API: ${e.message}`);
    }
  }
  // Optionally, open dashboard in browser (uncomment if desired)
  // spawn('xdg-open', [DASHBOARD_PATH], { detached: true });
  ensureHeartbeatDashboard.running = false;
}
setInterval(ensureHeartbeatDashboard, 10000); // Check every 10s

log('[RUNNING] All systems active - SIGHUP immune');
