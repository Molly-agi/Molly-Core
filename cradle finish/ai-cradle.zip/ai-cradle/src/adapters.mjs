/**
 * AI Cradle — model adapters
 *
 * The cradle's thaw() output is a plain string that works with ANY model.
 * These adapters shape that string into each provider's expected request
 * form. They are pure formatting — no SDKs, no network, no dependencies.
 * Portability is the point: the same cradle drives every provider.
 *
 * Usage:
 *   import { Cradle } from './cradle.mjs';
 *   import { formatFor } from './adapters.mjs';
 *   const prompt = new Cradle({ path: 'agent.cradle.md' }).thaw();
 *   const claude = formatFor('claude', prompt);   // { system }
 *   const openai = formatFor('openai', prompt);   // { role:'system', content }
 */

export const PROVIDERS = ['claude', 'anthropic', 'openai', 'gemini', 'google', 'ollama', 'raw'];

/**
 * Shape an assembled system prompt for a given provider.
 * @param {string} provider
 * @param {string} systemPrompt  the model-agnostic string from cradle.thaw()
 * @returns {object|string} provider-specific fragment to merge into your request
 */
export function formatFor(provider, systemPrompt) {
  if (typeof systemPrompt !== 'string') {
    throw new Error('formatFor: systemPrompt must be a string (use cradle.thaw())');
  }
  switch ((provider || '').toLowerCase()) {
    // Anthropic Claude — top-level `system` parameter on messages.create
    case 'claude':
    case 'anthropic':
      return { system: systemPrompt };

    // OpenAI / chat-completions — a system role message to prepend to messages[]
    case 'openai':
      return { role: 'system', content: systemPrompt };

    // Google Gemini — systemInstruction with parts
    case 'gemini':
    case 'google':
      return { systemInstruction: { role: 'system', parts: [{ text: systemPrompt }] } };

    // Ollama — `system` field on the generate/chat call
    case 'ollama':
      return { system: systemPrompt };

    // Raw — just the string
    case 'raw':
      return systemPrompt;

    default:
      throw new Error(
        `formatFor: unknown provider "${provider}". Known: ${PROVIDERS.join(', ')}`
      );
  }
}

export default formatFor;
