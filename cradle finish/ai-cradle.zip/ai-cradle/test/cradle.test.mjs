/**
 * AI Cradle — round-trip test
 * The point of a cradle is trust: freeze must NEVER corrupt the protected
 * identity core, and thaw must faithfully reconstitute it. Run:
 *   node test/cradle.test.mjs
 */

import { Cradle, renderState, MARKERS } from '../src/cradle.mjs';
import { formatFor } from '../src/adapters.mjs';
import { readFileSync } from 'node:fs';

let pass = 0, fail = 0;
const ok = (name, cond) => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
};

console.log('AI Cradle — round-trip test\n');

const template = readFileSync(new URL('../templates/agent.cradle.md', import.meta.url), 'utf8');

// Work in-memory (text mode) so the test touches no disk.
const cradle = new Cradle({ text: template });

// 1) parse() extracts the three sections.
const p = cradle.parse();
ok('parse finds identity core', p.identity && p.identity.includes('Who You Are'));
ok('parse finds state block', p.hasStateBlock === true);
ok('parse finds reference', p.reference && p.reference.includes('Project Reference'));

// 2) thaw() returns a clean, model-agnostic prompt with identity, no markers.
const prompt1 = cradle.thaw();
ok('thaw includes identity', prompt1.includes('You are <AGENT NAME>'));
ok('thaw includes directives', prompt1.includes('Never claim something works'));
ok('thaw strips marker comments', !prompt1.includes('CRADLE:IDENTITY:START'));

// Capture the exact identity bytes BEFORE freezing, to prove preservation.
const identityBefore = cradle.parse().identity;

// 3) freeze() updates the STATE block (in-memory, write:false).
const afterFreeze = cradle.freeze(
  {
    session: 'sess-001',
    status: 'active',
    topic: 'wiring the voice pipeline',
    lastAction: 'connected the mic switchboard',
    pending: ['test on device', 'handle reconnect'],
  },
  { write: false }
);
const c2 = new Cradle({ text: afterFreeze });
const p2 = c2.parse();
ok('freeze wrote new state (topic present)', p2.state.includes('wiring the voice pipeline'));
ok('freeze recorded session', p2.state.includes('sess-001'));
ok('freeze recorded pending items', p2.state.includes('test on device'));

// 4) THE INVARIANT: identity core preserved byte-for-byte across freeze.
ok('identity core preserved byte-for-byte', p2.identity === identityBefore);
ok('reference preserved', p2.reference && p2.reference.includes('Project Reference'));

// 5) thaw after freeze: new state AND identity both present.
const prompt2 = c2.thaw();
ok('thaw-after-freeze has new state', prompt2.includes('connected the mic switchboard'));
ok('thaw-after-freeze still has identity', prompt2.includes('You are <AGENT NAME>'));

// 6) freeze REPLACES state (no unbounded growth): old topic gone, new present.
const afterSecond = c2.freeze(
  { session: 'sess-002', status: 'active', topic: 'second task entirely' },
  { write: false }
);
const c3 = new Cradle({ text: afterSecond });
ok('second freeze replaced old topic (not appended)', !c3.parse().state.includes('wiring the voice pipeline'));
ok('second freeze has new topic', c3.parse().state.includes('second task entirely'));
ok('only one STATE block exists', afterSecond.split(MARKERS.stateStart).length - 1 === 1);
ok('identity STILL preserved after 2nd freeze', c3.parse().identity === identityBefore);

// 7) self-heal: a cradle with NO state block gets one appended on freeze.
const bare = new Cradle({ text: '# Bare\n\nJust identity, no state block.\n' });
const healed = bare.freeze({ status: 'active', topic: 'hello' }, { write: false });
ok('freeze self-heals missing state block', healed.includes(MARKERS.stateStart) && healed.includes('hello'));
ok('self-heal preserved original content', healed.includes('Just identity, no state block.'));

// 8) model adapters shape the SAME prompt correctly per provider.
ok('adapter: claude → { system }', formatFor('claude', prompt2).system === prompt2);
ok('adapter: openai → system message', (() => { const m = formatFor('openai', prompt2); return m.role === 'system' && m.content === prompt2; })());
ok('adapter: gemini → systemInstruction parts', formatFor('gemini', prompt2).systemInstruction.parts[0].text === prompt2);
ok('adapter: ollama → { system }', formatFor('ollama', prompt2).system === prompt2);
ok('adapter: raw → string', formatFor('raw', prompt2) === prompt2);
ok('adapter: unknown provider throws', (() => { try { formatFor('nope', prompt2); return false; } catch { return true; } })());

// 9) renderState handles custom fields without losing them.
ok('renderState keeps custom fields', renderState({ status: 'x', mood: 'focused' }).includes('mood'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
